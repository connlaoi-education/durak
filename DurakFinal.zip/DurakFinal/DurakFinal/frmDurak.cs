﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DurakGame;
using JeremyCards;

namespace DurakFinal
{
    public partial class frmDurak : Form
    {
        Game game;
        public frmDurak()
        {
            InitializeComponent();
        }

        private void frmDurak_Load(object sender, EventArgs e)
        {

        }

        private void newGame20ToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            game = new Game(20);
            StartGame();
        }
        private void newGame36CardsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            game = new Game(36);
            StartGame();
        }

        private void newGame52CardsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            game = new Game(52);
            StartGame();
        }
        private void StartGame()
        {
            pnlRiver.Controls.Clear();
            pnlOppHand.Controls.Clear();
            pnlPlayerHand.Controls.Clear();
            game.Players[0].StatusChanged += PlayerStatusHandler;
            game.Players[1].StatusChanged += AIStatusHandler;
            DetermineRandomAttacker();
            game.Players[0].Hand.CollectionChanged += PlayerHandHandler;
            game.Players[1].Hand.CollectionChanged += AIHandHandler;
            game.River.CollectionChanged += UpdateRiver;
            game.River.CollectionChanged += PlayerHandHandler;
            cbxTrump.Card = game.trumpCard;
            cbxTrump.FaceUp = true;
            game.Players[0].DrawToSix(game.Deck);
            game.Players[1].DrawToSix(game.Deck);
            UpdateDeckSize();

            if(game.Players[1].Status == Statuses.Attacking)
            {
                game.Players[1].Attack(game.River);
            }
        }

        public void UpdateRiver(object sender, EventArgs e)
        {
            pnlRiver.Controls.Clear();

            int offset = 0;
            for(int i = 0; i < game.River.Count; i++)
            {
                CardBox.CardBox cbx = new CardBox.CardBox
                {
                    Visible = true,
                    Card = game.River[i],
                    Width = cbxRiver.Width,
                    Height = cbxRiver.Height,
                    Left = cbxRiver.Left + ((i * (cbxRiver.Width / 3)) + offset),
                    Top = cbxRiver.Top
                };
                offset += 10;
                this.pnlRiver.Controls.Add(cbx);
            }
        }

        public void PlayerHandHandler(object sender, EventArgs e)
        {
            pnlPlayerHand.Controls.Clear();
            game.Players[0].UpdatePlayableCards(game);
            game.Players[1].UpdatePlayableCards(game);
            int offset = 0;
            for (int j = 0; j < game.Players[0].Hand.Count; j++)
            {
                CardBox.CardBox cbx = new CardBox.CardBox
                {
                    Visible = true,
                    Card = game.Players[0].Hand[j],
                    Width = cbxHand.Width,
                    Height = cbxHand.Height,
                    Left = cbxHand.Left + ((j * (cbxHand.Width / 3)) + offset)
                };
                offset += 10;
                cbx.Click += HandClickHandler;
                this.pnlPlayerHand.Controls.Add(cbx);

                if (game.Players[0].PlayableCards.Contains(game.Players[0].Hand[j]))
                {
                    cbx.Top = cbxHand.Top - 20;
                }
                else
                {
                    cbx.Top = cbxHand.Top;
                }

            }
        }

        public void HandClickHandler(object sender, EventArgs e)
        {
            CardBox.CardBox cardBoxClicked = (CardBox.CardBox)sender;
            PlayingCard cardClicked = cardBoxClicked.Card;
            if(game.Players[0].PlayableCards.Contains(cardClicked))
            {
                game.Players[0].Play(cardClicked, game.River);

                if (game.Players[1].Status == Statuses.Attacking)
                {
                    game.Players[1].Attack(game.River);
                }
            }

            

        }
        public void AIHandHandler(object sender, EventArgs e)
        {
            pnlOppHand.Controls.Clear();
            game.Players[0].UpdatePlayableCards(game);
            game.Players[1].UpdatePlayableCards(game);

            int offset = 0;
            for (int j = 0; j < game.Players[1].Hand.Count; j++)
            {
                PictureBox pbx = new PictureBox
                {
                    Visible = true,
                    BackgroundImage = new Bitmap(DurakFinal.Properties.Resources.back),
                    Width = pbxOppHand.Width,
                    Height = pbxOppHand.Height,
                    Left = pbxOppHand.Left + ((j * (pbxOppHand.Width) / 3) + offset),
                    Top = pbxOppHand.Top,
                    BackgroundImageLayout = ImageLayout.Stretch
                };
                offset += 10;
                this.pnlOppHand.Controls.Add(pbx);
            }
        }

        public void PlayerStatusHandler(object sender, EventArgs e)
        {
            Player handlePlayer = (Player)sender;
            lblPlayerStatus.Text = "Your Status: " + handlePlayer.Status;
        }
        public void AIStatusHandler(object sender, EventArgs e)
        {
            Player handlePlayer = (Player)sender;
            lblOppStatus.Text = "Opponent Status: " + handlePlayer.Status;
        }
        


        private void UpdateDeckSize()
        {
            lblCardsRemaining.Text = "Cards Remaining: " + game.Deck.getDeckSize().ToString();
        }
        
        private void DetermineRandomAttacker()
        {
            Random rand = new Random();
            if (rand.Next(0, 2) == 0)
            {
                game.Players[0].Status = Statuses.Attacking;
                game.Players[1].Status = Statuses.Defending;
            }
            else
            {
                game.Players[1].Status = Statuses.Attacking;
                game.Players[0].Status = Statuses.Defending;
            }
        }

    }
}
