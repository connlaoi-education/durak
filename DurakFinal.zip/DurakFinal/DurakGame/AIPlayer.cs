﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DurakGame
{
    class AIPlayer : Player
    {
        public override void Attack(River river)
        {
            if(PlayableCards.Count > 0)
            {
                this.Play(this.PlayableCards[0], river);
                this.firstTurn = false;
            }
        }
    }
}
