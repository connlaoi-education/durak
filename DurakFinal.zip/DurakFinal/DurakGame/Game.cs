﻿using JeremyCards;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DurakGame
{
    public class Game
    {
        public PlayingCard trumpCard;
        public CardSuit trumpSuit;
        private Deck deck;
        public Deck Deck
        {
            get { return deck; }
            set { deck = value; }
        }

        private List<Player> myPlayers = new List<Player>();
        public List<Player> Players
        {
            get { return myPlayers; }
            set { Players = value; }
        }
        private River river = new River();
        public River River
        {
            get { return river; }
            set { river = value; }
        }


        public Game()
        {
            Players.Clear();
            Player userPlayer = new Player();
            AIPlayer computer = new AIPlayer();
            Players.Add(userPlayer);
            Players.Add(computer);

            Deck = new Deck(true, CardSuit.Clubs, 52);
            Deck.Shuffle();
            trumpCard = Deck.GetCard(0);
            trumpSuit = trumpCard.Suit;
            River.Clear();
        }

        public Game(int deckSize)
        {
            Players.Clear();
            Player userPlayer = new Player();
            AIPlayer computer = new AIPlayer();
            Players.Add(userPlayer);
            Players.Add(computer);

            deck = new Deck(true, CardSuit.Clubs, deckSize);
            Deck.Shuffle();
            trumpCard = Deck.GetCard(0);
            trumpSuit = trumpCard.Suit;
            River.Clear();
        }
    }
}